package day1;

public class typeexam {

	public static void main(String[] args) {
		int a=5;
		char b='A';
		double c=2.5;
		double result=a+b*c;
		System.out.println("(a+b*c) ="+result);
	}
}